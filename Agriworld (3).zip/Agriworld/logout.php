<?php
 session_start();
 if (isset($_SESSION['loginid'])) {
    session_destroy();
 }
 header('Location:login.php');
?>