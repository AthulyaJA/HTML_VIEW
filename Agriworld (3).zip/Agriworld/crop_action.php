<?php
require "database.php";
$fname=$_POST['crop_name'];
  $lname=$_POST['price'];
  $date=$_POST['uploadfile'];
  
  
  
  
  $conn->exec($sql);
  echo $date;
  //$sqlr="INSERT INTO tb_crop(crop_name,price,Filename) values('$fname','$lname','$date')";
//$conn->exec($sqlr);
  //echo "New record created successfully";
  //header('location:farmer_reg.php');
  
  
?>