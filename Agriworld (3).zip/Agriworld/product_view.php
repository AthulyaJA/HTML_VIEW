<?php
session_start();
$id=$_SESSION['loginid'];
$mysql=new mysqli("localhost","root","","agriworld");
?>
<html>
<head>





<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="css/styleform.css" rel="stylesheet" type="text/css" media="all" />
<!-- //Custom Theme files -->
<!-- web font -->
<link href="//fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,700,700i" rel="stylesheet">
<!-- //web font -->
<style>
table,th,td{
	border:2px solid black;
	padding:2px;
	border-collapse:collapse;
}
	
	

</style>
</head>
<body>
	<!-- main -->
	<div class="main-w3layouts wrapper">
		<h1>Products</h1>
		
		<!-- copyright -->
		<div class="colorlibcopy-agile">
			<p><a href="https://colorlib.com/" target="_blank"></a></p>
		</div>
		<!-- //copyright -->
		<ul class="colorlib-bubbles">
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
		</ul>
	</div>
	<!-- //main -->






<form> 
<table>
<center>
 <tr> 

 <th>Product</th>
 <th>Price</th>
 <th>Image</th>
 <th>Buy</th>
 


 
 
 </tr>
 <?php


$mysql=new mysqli("localhost","root","","agriworld");
$query=$mysql->query("select * from tb_product");




	foreach($query as $value=>$row)
    {
	 
     echo "<tr>	 
	 <td>".$row['product']."</td>
	 <td>".$row['price']."</td>
	 <td> <img src="."images/".$row['image_details']." height=100px width=100px></td>";
?>

<td>
<a href="buyproduct.php?id= <?php echo $row['id'];?> ">Buy</a>


<?php	 
	 
	echo " </tr>";
     

   }
   

?>
</table>
</form>

</body>
</html>