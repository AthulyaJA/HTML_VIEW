<?php
class Mainmodel extends CI_model{
    public function tbtreg($a,$b){
        $this->db->insert("tb_login",$b);
        $loginid = $this->db->insert_id();
        $a['loginid']=$loginid;
        $this->db->insert("tb_trainer",$a);
    }
    public function encpass($pass){
        return password_hash($pass,PASSWORD_BCRYPT);
    }
 
 
//office staff mainmodel
 
public function register($a)
{
    $this->db->insert("tb_staff",$a);
 
}
 
public function newtb($a,$b)
{
    $this->db->insert("tb_login",$b);
    $loginid=$this->db->insert_id();
    $a['loginid']=$loginid;
    $this->db->insert("tb_staff",$a);
}
 
public function reg1()
          {
              $this->db->select('*');
              $this->db->join('tb_login','tb_login.id=tb_staff.loginid','inner');
              $cab=$this->db->get("tb_staff");
               return $cab;
          }
//student (athulya)registarion /updation
 
public function reg_access($a,$b) 
  {
      $this->db->insert("tb_login",$b);
      $loginid=$this->db->insert_id();
      $a['loginid']=$loginid;
      $this->db->insert("tb_student",$a);
      
  } 
  public function encpass1($pass)
  {
    return password_hash($pass,PASSWORD_BCRYPT);
  }
   public function view()
  {
    $this->db->select('*');
    $this->db->join('tb_login','tb_login.id=tb_student.loginid','inner');
    $qry=$this->db->get("tb_student");
    return $qry;
  }
 
 
  public function updatedetails1($b,$c,$id)
             {
              $this->db->select("*");
               $qry=$this->db->where("tb_student.loginid",$id);
               $qry=$this->db->join('tb_login','tb_login.id=tb_student.loginid','inner');
               $qry=$this->db->update("tb_student",$b);
               $qry=$this->db->where("tb_login.id",$id);
                $qry=$this->db->update("tb_login",$c);
                return $qry;
                
 
             }
//view job vacancy table
public function views()
          {
              $this->db->select('*');
              $cab=$this->db->get("tb_vacancy");
              return $cab;
          }
 
 
 //insert the complaint
            
 public function notiteach($a)
{
$this->db->insert("tb_complaint",$a);

}
//view complaint by athulya
public function addno()
  {
    $this->db->select('*');
    $this->db->join('tb_student','tb_student.loginid=tb_complaint.loginid','inner');
    $qry=$this->db->get("tb_complaint");
    return $qry;
  }

  public function addone($id)
  {
    $this->db->select('*');
  
    $qry=$this->db->get("tb_complaint");
    return $qry;
  }

//login action(rubiya)
public function newpasslog($email,$password)
          {
              $this->db->select('password');
              $this->db->from("tb_login");
              $this->db->where("user_name",$email);
              $qry=$this->db->get()->row('password');
              return $this->verifypass($password,$qry);
          }
          public function verifypass($password,$qry)
          {
              return password_verify($password,$qry);
          }
          public function getuserid($email)
{
    $this->db->select('id');
    $this->db->from("tb_login");
    $this->db->where("user_name",$email);
    return $this->db->get()->row('id');
}
public function getuser($id)
{
    $this->db->select('*');
    $this->db->from("tb_login");
    $this->db->where("id",$id);
    return $this->db->get()->row();

}
 
//note insert (athulya)
public function notes_add($a)
{
  $this->db->insert('tb_note',$a);
}
public function notes_join()
  {
    $this->db->select('*');
    $this->db->join('tb_trainer','tb_trainer.loginid=tb_note.loginid','inner');
    $qry=$this->db->get("tb_note");
    return $qry;
  }
  public function note_get($id)
  {
    $this->db->select('*');
  
    $qry=$this->db->get("tb_note");
    return $qry;
  }
}