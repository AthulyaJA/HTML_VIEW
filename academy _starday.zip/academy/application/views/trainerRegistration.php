<html>
<body>
<form action="<?php echo base_url() ?>amsctrl/trainerAction" method="post" enctype="multipart/form-data">
Name: <input type="text" name="name"></br>
Address:<textarea type="text" name="address"></textarea></br>
District:<select name="district">
    <option value="trivandrum">Trivandrum</option>
    <option value="kollam">Kollam</option>
    <option value="pathanamthitta">Pathanamthitta</option>
    <option value="alappuzha">Alappuzha</option>
</select></br>
pincode:<input type="text" name="pincode"></br>
Phonenumber:<input type="text" name="phone"></br>
Gender:<input type="radio" name="gender" value="male">Male
       <input type="radio" name="gender" value="female">female</br>
DOB:<input type="date" name="dob"><br>
Subject:<select name="subject" >
    <option value="Java">java</option>
    <option value="php">php</option>
    <option value="c">C</option>
</select></br>
email:<input type="email" name="email"></br>
<input type="file" name="pic" id="pic"></br>
Password:<input type="password" name="pass"></br>
<input type="submit" name="sub">
</form>




</body>


</html>