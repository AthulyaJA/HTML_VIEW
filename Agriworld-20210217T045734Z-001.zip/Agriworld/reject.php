<?php
$mysql=new mysqli("localhost","root","","agriworld");
$query=$mysql->query("select * from tb_farmer");

$id=$_GET['id'];
$sql="update tb_farmer set status='2' where id=$id";

  
?>