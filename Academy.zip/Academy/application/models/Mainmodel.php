<?php
class Mainmodel extends CI_model
{
	
}