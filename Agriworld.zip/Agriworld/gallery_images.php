<html>
<head>
<title>first site</title>
<link rel="stylesheet" href="css/styleform.css">

<style>


.menubar ul li
{
	padding:15px;
}
.menubar
{
	background-color:#936c6c;
	text-align:center;
}
.menubar ul
{
	list-style:none;
	display:inline-flex;
}
.menubar ul li a
{
	color:white;
	text-decoration:none;
}


body{
background-color:rgba(0,0,0,0.2);

    }
.gal{
text-align:center;

    }
.gal img{
    width:300px;
height:150px;
margin:30px;
box-shadow:10px 10px 5px grey;

transition:1s;


        }
.gal img:hover{
           
transform:scale(1.2);
cursor:pointer;

 }



</style>
</head>
<body class="bi">
<!------- navigation starts------->
<nav class="menubar">
	<ul>
		<li><a href="index.php">Home</a></li>
		
		<li><a href="logout.php"> logout</a>
		
			<div class="submenu">
				<ul>
					<li><a href="#"></li>
					<li><a href="#"></li>
				</ul>
			</div>
		</li>
		<li><a href=""> Contact us</a></li>
	</ul>
</nav>

<body>
<h1>gallery</h1>
<div class="gal">
<img src="images/111.webp">
<img src="images/112.webp">
<img src="images/113.jpg">
<img src="images/114.jpeg">
<img src="images/115.jpeg">
<img src="images/116.jpg">
<img src="images/117.png">
<img src="images/farmer.jpeg">
</div>
</body>
</html>
