<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Athu extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

public function index()
	{
		$this->load->view('print');
	}
	public function reg()
	{
		$this->load->view('print');
	}

public function register()

	
	
	{
		$this->load->library('form_validation');
		$this->load->model('Mainmodel');
		$this->form_validation->set_rules("name","studentname",'required');
		$this->form_validation->set_rules("address","useraddress",'required');
		$this->form_validation->set_rules("gender","usergender",'required');
		$this->form_validation->set_rules("age","userage",'required');
		$this->form_validation->set_rules("email","useremail",'required');
		$this->form_validation->set_rules("password","userpassword",'required');
	if($this->form_validation->run())
	{
		$pass=$this->input->post("password");
		$encpass=$this->Mainmodel->encpass($pass);
		$a=array("name"=>$this->input->post("name"),
		"address"=>$this->input->post("address"),
		"gender"=>$this->input->post("gender"),
		"age"=>$this->input->post("age"),
		"email"=>$this->input->post("email"),
		"password"=>$encpass);
		$this->Mainmodel->register($a);
		redirect(base_url().'Athu/form');
	
	}
	}






	public function tb()
	{
		/*$this->load->view('form');*/
		$this->load->model('Mainmodel');
		$data['n']=$this->Mainmodel->view1();
		$this->load->view('form',$data);
	}
   





	public function updatedetails()
	{
		$a=array("name"=>$this->input->post("Name"),
        		"address"=>$this->input->post("Address"),
        		"age"=>$this->input->post("Age"),
        		"gender"=>$this->input->post("Gender"),
        	    "email"=>$this->input->post("Email"));

        	    $id=$this->uri->segment(3);
        	    $this->load->model('Mainmodel');
        	    $data['user_data']=$this->Mainmodel->singledetails($id);
        	    $this->Mainmodel->singledata();
        	    $this->load->view('form',$data);
        	    if($this->input->post("update"))
        	    {
        	    	$this->Mainmodel->updatedetails($a,$this->input->post("id"));
        	    	 redirect(base_url().'Athu/tb');
                 }
     }

   public function deletedetails()
   {
   $this->load->model('Mainmodel');
   $id=$this->uri->segment(3);
   $this->Mainmodel->deletedetails($id);
   redirect(base_url().'Athu/tb');

	}
	public function approvel(){


	$this->load->model('Mainmodel');
   $id=$this->uri->segment(3);
   $this->Mainmodel->approvel($id);
   redirect(base_url().'Athu/tb');
	}
	


	public function rejected(){


	$this->load->model('Mainmodel');
   $id=$this->uri->segment(3);
   $this->Mainmodel->rejected($id);
   redirect(base_url().'Athu/tb');
	}
	public function log()
	{
		$this->load->view('login');
	}
	
	public function login()
	{
		/*$this->load->model('Mainmodel');
		$this->load->view('login');*/
		
    $this->load->library('form_validation');
    $this->form_validation->set_rules("email","email",'required');
    $this->form_validation->set_rules("password","password",'required');
    if($this->form_validation->run())
    {
       			 $this->load->model('Mainmodel');
        		$email=$this->input->post("email");
        		$pass=$this->input->post("password");
        		$rslt=$this->Mainmodel->selectpass($email,$pass);
        if($rslt)
        {
            	$id=$this->Mainmodel->getuserid($email);

            	$user=$this->Mainmodel->getuser($id);
            	$this->load->library(array('session'));
            	$this->session->set_userdata(array('id'=>(int)$userid->id,'status'=>$user->status));
            	
            	if($_SESSION['status']=='1')
            		{
                		redirect(base_url().'Athu/tb');
            		}
            
            	else
            
            		{
                		echo"waiting for approvel";
            		}

        }

        else
        {
            echo"invalid user";
         }

	}
else
{
    redirect(base_url().'Athu/login');
}
        
 }   
public function rs()
{
	$this->load->view('regist');
}
public function insert()	
{

		$this->load->library('form_validation');
		$this->load->model('Mainmodel');
		$this->form_validation->set_rules("fname","firstname",'required');
		$this->form_validation->set_rules("lname","lastname",'required');
		$this->form_validation->set_rules("Address","Address",'required');
		$this->form_validation->set_rules("location","location",'required');
		$this->form_validation->set_rules("pincode","pincode",'required');
		$this->form_validation->set_rules("dob","date",'required');
		$this->form_validation->set_rules("phno","phone",'required');
		$this->form_validation->set_rules("gender","gender",'required');
		$this->form_validation->set_rules("education","edu",'required');
		/*$this->form_validation->set_rules("loid","id",'required');*/
        $this->form_validation->set_rules("email","email",'required');
        $this->form_validation->set_rules("password","pass",'required');
	if($this->form_validation->run())
	{
		$pass=$this->input->post("password");
		$encpass=$this->Mainmodel->encpass($pass);
		$a=array("fname"=>$this->input->post("fname"),
		"lname"=>$this->input->post("lname"),

	    "Address"=>$this->input->post("Address"),
		"District"=>$this->input->post("location"),
		"pincode"=>$this->input->post("pincode"),
		"DOB"=>$this->input->post("dob"),
		"phone"=>$this->input->post("phno"),
		"Gender"=>$this->input->post("gender"),
		"Education"=>$this->input->post("education"));
		/*"loid"=>$this->input->post("loid"));*/
		$b=array("email"=>$this->input->post("email"),
		"password"=>$encpass);
		$this->Mainmodel->regist($a,$b);

		redirect('Athu/rs','refresh');

	
	}


}

	public function vie()
	{
		/*$this->load->view('form');*/
		$this->load->model('Mainmodel');
		$data['n']=$this->Mainmodel->ana();
		$this->load->view('reg',$data);
	}

public function qu()
{
	$this->load->view('reg');
}

public function app(){


	$this->load->model('Mainmodel');
   $id=$this->uri->segment(3);
   $this->Mainmodel->app($id);
   redirect(base_url().'Athu/vie');
	}
	


	public function rej(){


	$this->load->model('Mainmodel');
   $id=$this->uri->segment(3);
   $this->Mainmodel->rej($id);
   redirect(base_url().'Athu/vie');
	}
}

?>