

<html>
<head>
<title></title>
<style>
 
</style>
<body>
<form action="<?php echo base_url()?>amsctrl/loginAction"  method="post">
<h1>LOGIN</h1>
email :<input type="email" name="user_name"><br><br>
password:<input type="password" name="password"><br><br>
<input type="submit" value="login">
</form>
</body>
</html>