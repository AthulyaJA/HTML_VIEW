<html>
<head>
<title>form</title>
<style>



form{
    text-align:center;
}
</style>
</head>
<body>
<form  method="post" action="<?php echo base_url()?>amsctrl/register" enctype="multipart/form-data">

<h1><b>STAFF REGISTRATION</b></h1>
<div class="a">
 Name:<input type="text" name="Name" ></br><br>
Address:<textarea type="text" name="Address"></textarea></br><br>
District:<input list="location1" name="district" ></br><br>
<datalist id="location1">
<option value="Thiruvananthapuram">
<option value="Kollam">
<option value="Palakkad">
<option value="Kottayam">
</datalist>
Pincode:<input type="text" name="Pincode"></br><br>
Phone number:<input type="text" name="Phoneno"></br><br>
Dob:<input type="date" name="dob"></br><br>
Gender:<input type="radio"  name="gender"  value="male">M 
       <input type="radio" name="gender"  value="female">F</br><br>

Section:
<select name="section">
<option value="qh">QH</option>
<option value="finance">Finance</option>
<option value="Operation Head">Operation Head</option>
<option value="Project Head">Project Head</option>
<option value="Manager">Manager</option>
<option value="Assistant">Assistant</option>

</select></br><br>

Email:<input type="email" name="email"></br><br>
<input type="file" name="pic" id="pic"></br></br>
Password:<input type="password" name="password"></br><br><br>
<input type="submit" value="register">
</div>
</form>
</body>
</html>