<!DOCTYPE html>
<html>
<head>
<style>
input
{
	padding:10px;
	margin:10px;
}
	

</style>
<body>
<h1>Login</h1>
<form action="authenti.php" method="post"><pre>
  <input type="email" name="email1" placeholder="username"><br>
  <input type="password" name="pass1" placeholder="password"><br>
  
<input type="submit" value="login"></pre>
</form>
</body>
</html>