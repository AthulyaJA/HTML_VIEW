<?php


$mysql=new mysqli("localhost","root","","athulya");
$email=$_POST['email1'];
$pass=$_POST['pass1'];
$sql="select * from register where email='$email' and password='$pass'";

if ($_SERVER['REQUEST_METHOD'] == 'POST') 
	{ 
    if (($_POST['email'])!=($email]))
		
    { 
        echo 
        "Incorrect username or password";
         
    } 
	
	else
	{
		echo "login suucuess";
	}
	}
	 

?>



