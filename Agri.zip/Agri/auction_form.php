
<!DOCTYPE html>
<html>
<head>

<!-- //web font -->
<title>Auction form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="css/styleform.css" rel="stylesheet" type="text/css" media="all" />
<!-- //Custom Theme files -->
<!-- web font -->
<link href="//fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,700,700i" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="css/styleform.css" rel="stylesheet" type="text/css" media="all" />
<!-- //Custom Theme files -->
<!-- web font -->
<link href="//fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,700,700i" rel="stylesheet">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Lato%3A100%2C100italic%2C300%2C300italic%2Cregular%2Citalic%2C700%2C700italic%2C900%2C900italic&amp;subset=latin&amp;' type='text/css' media='all' />
   <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Noto+Sans%3Aregular%2Citalic%2C700%2C700italic&amp;subset=greek%2Ccyrillic-ext%2Ccyrillic%2Clatin%2Clatin-ext%2Cvietnamese%2Cgreek-ext&amp;' type='text/css' media='all' />
    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Merriweather%3A300%2C300italic%2Cregular%2Citalic%2C700%2C700italic%2C900%2C900italic&amp;subset=latin%2Clatin-ext&amp;' type='text/css' media='all' />
    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Mystery+Quest%3Aregular&amp;subset=latin%2Clatin-ext&amp;' type='text/css' media='all' />

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <link rel='stylesheet' href='css/style.css' type='text/css' media='all' />
    <link rel='stylesheet' href='plugins/superfish/css/superfish.css' type='text/css' media='all' />
    <link rel='stylesheet' href='plugins/dl-menu/component.css' type='text/css' media='all' />
    <link rel='stylesheet' href='plugins/font-awesome-new/css/font-awesome.min.css' type='text/css' media='all' />
    <link rel='stylesheet' href='plugins/elegant-font/style.css' type='text/css' media='all' />
    <link rel='stylesheet' href='plugins/fancybox/jquery.fancybox.css' type='text/css' media='all' />
    <link rel='stylesheet' href='plugins/flexslider/flexslider.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/style-responsive.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/style-custom.css' type='text/css' media='all' />
    <link rel='stylesheet' href='plugins/masterslider/public/assets/css/masterslider.main.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/master-custom.css' type='text/css' media='all' />
 <!--//web font -->



<style>
 table,th,td,tr{
	        border:2px solid red;
			padding:10px;
			border-collapse:collapse;
            }
			
input {
        padding:20px;
		margin:20px;
		text-align:center;
	  }

  .cen
  {  background-color:rgba(0,0,0,0.6);
  	color:white;
  	margin-top:-50px;
  	margin-left: 500px;
  }
.for
{
	margin-top:200px;
}
.far
{
background-image:url('images/ric.jpg');
}
.shade
{
	background-color:rgba(0,0,0,0.6);

}
td
{
	color:white;
}
</style>
</head>

		
		
		<!-- copyright -->
		




<!-- main -->


<body data-rsssl=1 class="home page-template-default page page-id-5680 _masterslider _msp_version_3.2.7 woocommerce-no-js">
    <div class="body-wrapper  float-menu" data-home="https://demo.goodlayers.com/greennature/">
        <header class="greennature-header-wrapper header-style-5-wrapper greennature-header-with-top-bar">
            <!-- top navigation -->
            <div class="top-navigation-wrapper">
                <div class="top-navigation-container container">
                    <div class="top-navigation-left">
                        <div class="top-navigation-left-text">
                            Phone : +918845566      Email :agriworld@gmail.com </div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            <div id="greennature-header-substitute"></div>
            <div class="greennature-header-inner header-inner-header-style-5">
                <div class="greennature-header-container container">
                    <div class="greennature-header-inner-overlay"></div>
                    <!-- logo -->
                    <div class="greennature-logo">
                        <div class="greennature-logo-inner">
                            <a href="index-2.html"><h3 style="color:green">Agri-World</h3>		
                               <!-- <img src="images/logo.png" alt="" /> </a>-->
                        </div>
                        <div class="greennature-responsive-navigation dl-menuwrapper" id="greennature-responsive-navigation">
                            <button class="dl-trigger">Open Menu</button>
                            <ul id="menu-main-menu" class="dl-menu greennature-main-mobile-menu">
                                <li class="menu-item menu-item-home current-menu-item page_item page-item-5680 current_page_item"><a href="index-2.html" aria-current="page">Home</a></li>
                                <li class="menu-item menu-item-has-children menu-item-15"><a href="#">Registration</a>
                                    <ul class="dl-submenu">
                                        <li class="menu-item"><a href="act-now.html">Farmer</a></li>
                                        <li class="menu-item"><a href="about-1.html">seller</a></li>
                                        <li class="menu-item"><a href="about-2.html">About Us 2</a></li>
                                        <li class="menu-item"><a href="service.html">Service</a></li>
                                        <li class="menu-item"><a href="personnel-2.html">Personnel</a></li>
										
                                        
                                        <li class="menu-item"><a href="contact-page.html">Contact Page 1</a></li>
                                        <li class="menu-item"><a href="contact-page-2.html">Contact Page 2</a></li>
                                        <li class="menu-item menu-item-12"><a href="404error.html">404 Page</a></li>
                                        <li class="menu-item"><a href="testimonial.html">Testimonial</a></li>
                                        <li class="menu-item menu-item-has-children"><a href="gallery-3-columns-without-caption.html">Gallery</a>
                                            <ul class="dl-submenu">
                                                <li class="menu-item"><a href="gallery-2-columns-without-caption.html">Gallery 2 Columns Without Caption</a></li>
                                                <li class="menu-item"><a href="gallery-2-columns-with-caption.html">Gallery 2 Columns With Caption</a></li>
                                                <li class="menu-item"><a href="gallery-3-columns-without-caption.html">Gallery 3 Columns Without Caption</a></li>
                                                <li class="menu-item"><a href="gallery-3-columns-with-caption.html">Gallery 3 Columns With Caption</a></li>
                                                <li class="menu-item"><a href="gallery-4-columns-without-caption.html">Gallery 4 Columns Without Caption</a></li>
                                                <li class="menu-item"><a href="gallery-4-columns-with-caption.html">Gallery 4 Columns With Caption</a></li>
                                                <li class="menu-item"><a href="gallery-5-columns-without-caption.html">Gallery 5 Columns Without Caption</a></li>
                                                <li class="menu-item"><a href="gallery-5-columns-with-caption.html">Gallery 5 Columns With Caption</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li class="menu-item menu-item-has-children"><a href="portfolio-grid-3-columns-no-space.html">Portfolio</a>
                                    <ul class="dl-submenu">
                                        <li class="menu-item menu-item-has-children"><a href="portfolio-grid-3-columns.html">Portfolio Classic</a>
                                            <ul class="dl-submenu">
                                                <li class="menu-item"><a href="portfolio-grid-1-column.html">Portfolio Grid 1 Column (Both Sidebar)</a></li>
                                                <li class="menu-item"><a href="portfolio-grid-2-columns.html">Portfolio Grid 2 Columns (Right Sidebar)</a></li>
                                                <li class="menu-item"><a href="portfolio-grid-3-columns.html">Portfolio Grid 3 Columns</a></li>
                                                <li class="menu-item"><a href="portfolio-grid-4-columns.html">Portfolio Grid 4 Columns</a></li>
                                                <li class="menu-item"><a href="portfolio-grid-2-columns-no-space.html">Portfolio Grid 2 Columns, No Space</a></li>
                                                <li class="menu-item"><a href="portfolio-grid-3-columns-no-space.html">Portfolio Grid 3 Columns, No Space</a></li>
                                                <li class="menu-item"><a href="portfolio-grid-4-columns-no-space.html">Portfolio Grid 4 Columns, No Space</a></li>
                                            </ul>
                                        </li>
                                        <li class="menu-item menu-item-has-children"><a href="portfolio-modern-3-columns-with-filter.html">Portfolio With Filter</a>
                                            <ul class="dl-submenu">
                                                <li class="menu-item"><a href="portfolio-grid-1-columns-with-filter.html">Portfolio Grid 1 Col With Filter</a></li>
                                                <li class="menu-item"><a href="portfolio-grid-2-columns-with-filter.html">Portfolio Grid 2 Cols With Filter</a></li>
                                                <li class="menu-item"><a href="portfolio-grid-3-columns-with-filter.html">Portfolio Grid 3 Cols With Filter</a></li>
                                                <li class="menu-item"><a href="portfolio-grid-4-columns-with-filter.html">Portfolio Grid 4 Cols With Filter</a></li>
                                                <li class="menu-item"><a href="portfolio-modern-3-columns-with-filter.html">Portfolio Modern 3 Cols With Filter</a></li>
                                                <li class="menu-item"><a href="portfolio-modern-4-columns-with-filter.html">Portfolio Modern 4 Cols With Filter</a></li>
                                                <li class="menu-item"><a href="singleprod.html">Single Portfolio</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li class="menu-item menu-item-has-children"><a href="blog-full-with-right-sidebar.html">Blog</a>
                                    <ul class="dl-submenu">
                                    	<li class="menu-item"><a href="blog-full-with-right-sidebar.html">Blog Full</a></li>

                                        <li ss="menu-item menu-item-has-children menu-item-"><a href="#">Blog Column</a>
                                            <ul class="dl-submenu">
                                                <li class="menu-item"><a href="blog-1-column.html">Blog 1 Column (Right Sidebar)</a></li>
                                                <li class="menu-item"><a href="blog-2-columns.html">Blog 2 Columns (Right Sidebar)</a></li>
                                                <li class="menu-item"><a href="blog-3-columns.html">Blog 3 Columns</a></li>
                                                <li class="menu-item"><a href="blog-4-columns.html">Blog 4 Columns</a></li>
                                            </ul>
                                        </li>
                                        <li class="menu-item menu-item-has-children menu-item-7"><a href="#">Blog Masonry</a>
                                            <ul class="dl-submenu">
                                                <li class="menu-item"><a href="blog-2-columns-masonry.html">Blog 2 Columns &#8211; Masonry (Right Sidebar)</a></li>
                                                <li class="menu-item"><a href="blog-3-columns-masonry.html">Blog 3 Columns – Masonry</a></li>
                                                <li class="menu-item"><a href="blog-4-columns-masonry.html">Blog 4 Columns – Masonry</a></li>
                                            </ul>
                                        </li>

                                    </ul>
                                </li>
       
                            </ul>
                        </div>
                    </div>

                    <!-- navigation -->
                    <div class="greennature-navigation-wrapper">
                        <nav class="greennature-navigation" id="greennature-main-navigation">
                            <ul id="menu-main-menu-1" class="sf-menu greennature-main-menu">
                                <li class="menu-item menu-item-home current-menu-item greennature-normal-menu"><a href="Admin_home.php"><i class="fa fa-home"></i>Home</a>
								
								<li class="menu-item menu-item-home current-menu-item greennature-normal-menu"><a href="auction_form.php"><i class="fa fa-home"></i>AUCTION</a></li>
								<li class="menu-item menu-item-has-children greennature-normal-menu"><a href="crop_add.php" class="sf-with-ul-pre"><i class="fa fa-file-text-o"></i>CROP PRICE</a>
                                    <li class="menu-item menu-item-has-childrenmenu-item menu-item-has-children greennature-mega-menu"><a href="not_loan.php" class="sf-with-ul-pre"><i class="fa fa-globe"></i>Add loan notification</a>
                                        <li class="menu-item menu-item-has-children"><a href="gallery_images.php" class="sf-with-ul-pre">Gallery</a>
                                    <ul class="sub-menu">
                                        <!--<li class="menu-item"><a href="farmer_reg.php">Farmer</a></li>
                                        <li class="menu-item"><a href="selling.php">Seller</a></li>
                                        <li class="menu-item"><a href="about-2.html">About Us 2</a></li>
                                        <li class="menu-item"><a href="service.html">Service</a></li>
                                        <li class="menu-item"><a href="personnel-2.html">Personnel</a></li>
                                        <li class="menu-item"><a href="qa.html">Q&#038;A</a></li>
                                        <li class="menu-item"><a href="contact-page.html">Contact Page 1</a></li>
                                        <li class="menu-item"><a href="404error.html">404 Page</a></li>
                                        <li class="menu-item"><a href="testimonial.html">Testimonial</a></li>-->
                                        <!---<li class="menu-item menu-item-has-children"><a href="gallery-3-columns-without-caption.html" class="sf-with-ul-pre">Gallery</a>--->
                                            
                                        </li>
                                    </ul>
                               
                                <li class="menu-item menu-item-has-childrenmenu-item menu-item-has-children greennature-mega-menu"><a href="logout.php" class="sf-with-ul-pre"><i class="fa fa-globe"></i>Logout</a>
                                    <div class="sf-mega">
                                        
                                    </div>
                                </li>
                                
                            </ul>
                            

                        </nav>
                        <div class="greennature-navigation-gimmick" id="greennature-navigation-gimmick"></div>
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
        </header>

                    
    

<div class="far">

<form action="insert_auction.php" method="get" class="for">	

<div class=" col-5 cen">
<h1 class="text-white">Auction Form</h1>
Crop name:</br><input type="text" name="cr"> </br>
Min Price:</br><input type="text" name="min"></br>
Quantity:</br><input type="text" name="qu"></br>
Date:</br><input type="date" name="date"></br>
<input type="submit" value="submit" class="btn btn-block bg-danger">
			

	<!-- //main --></div>
 <a href="Admin_home.php"  class="btn btn-outline-primary">< Previous</a>
<div class="shade">
<table class="table">
<thead>
   <tr>
       <th>Id</th>
       <th>Crop name</th>
	   <th>Min price</th>
	   <th>Quantity</th>
	   <th>Date</th>
	    <th>Action</th>

	</tr>
</thead>
<tbody>
<?php
$link=mysqli_connect("localhost","root","","agriworld");
if($link===false)
{
die("Error:could not connect".mysqli_connect_error());
}
$sql="select * from tb_auction";
if(mysqli_query($link, $sql))
	
{
	$result=mysqli_query($link, $sql);
	while($row=mysqli_fetch_assoc($result))
   {
	echo  "<tr>
	       <td>".$row['id']."</td>
		   <td>".$row['crop_name']."</td>
		   <td>".$row['minprice']."</td>
		   <td>".$row['quantity']."KG</td>
		   <td>".$row['date']."</td>
		   <td><a href='delet_auct.php?id=".$row['id']."'>Delete<?a>/
           <a href='form_auction_update.php?id=".$row['id']."'>Update<?a></td>
		   </tr>";

    }

}


else
{
echo "error $sql".mysqli_error($link);
}
mysqli_close($link);
?>
</tbody>

</table>
</div>
</form>
</div>
</body>
</html>



