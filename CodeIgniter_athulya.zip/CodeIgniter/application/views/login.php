<!DOCTYPE html>
<html>
<head>
	<style>

		input
		{

			margin:2px;
		}
	</style>
</head>

<body>

     <form action="<?php echo base_url()?>Athu/login" method="post">

     	<h1>LOGIN</h1><br>
     	Email-id:<input type="email" name="email"><br>
     	Password:<input type="Password" name="password">
     	<input type="submit" value="login">
     </form>




	</body>
</html>