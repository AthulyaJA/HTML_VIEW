<?php
class Mainmodel extends CI_model
{
	public function reg($a)
	{
		$this->db->insert("myform1",$a);
	}
public function encapass($pass)
{
	return password_hash($pass,PASSWORD_BCRYPT);
}

public function view1()
{
	$this->db->select('*');
	$qry=$this->db->get("myform1");

	return $qry;
}
/*public function update()
{
	$a=array('name'=>$this->input->post("Name"),
		'Address'=>$this->input->post("Address"),
		'Gender'=>$this->input->post("Gender"),
		'Age'=>$this->input->post("Age"),
		'Email'=>$this->input->post("Email"));
	$id=$this->uri->segment(3)
    $this->load->model('Mainmodel')
}*/
public function singledetails($id)
	    {
	    	$this->db->select('*');
	    	$this->db->where("id",$id);
	    	$qry=$this->db->get("myform1");
            return $qry;  
             }
    public function singledata()
	    {
	    	$qry=$this->db->get("myform1");
	 		return $qry;  
             }
    public function updatedetails($a,$id)
	    {
	    	$this->db->select('*');
	    	$this->db->where("id",$id);
	    	$qry=$this->db->update("myform1",$a);
            return $qry;  
         }

public function deletedetails($id)
{


	    	
	    	$this->db->where("id",$id);
	    	$this->db->delete("myform1");
           

}

public function approvel($id){


            

        $qry=$this->db->where("id",$id);
        /*$this->db->group_by('status', $status); */ 
        $qry=$this->db->set("status",'1');
        $qry=$this->db->update("myform1");
            return $qry; 

			/*$this->db->where("status",$status);
	    	$this->db->approvel("myform1");*/
           

					}
 public function rejected($id){
	         
        
        $qry=$this->db->where("id",$id);
       /* $this->db->group_by('status', $status);  */
        $qry=$this->db->set("status",'2');
        $qry=$this->db->update("myform1");
            return $qry; 

		
           

					}

	public function getuserid($email)
{
  $this->db->select('id');
  $this->db->from("myform1");
  $this->db->where("email",$email);
  return $this->db->get()->row('id');

}
public function getuser($id)
{
  $this->db->select('*');
  $this->db->where("id",$id);
  $this->db->get("myform1");
  $this->db->get()->row();
}
public function selectpass($email,$pass)
{
  $this->db->select('password');
  $this->db->from("myform1");
  $this->db->where("email",$email);
  $qry= $this->db->get()->row('password');
  return $this->verifypass($pass,$qry);
 
}
public function verifypass($pass,$qry)
{
  return password_verify($pass,$qry);
}
public function encpass($pass)
{
	return password_hash($pass,PASSWORD_BCRYPT);
}

public function regist($a,$b){

	/*$this->db->insert("tableone",$a);*/


	$this->db->insert("tabletwow",$b);
	$log=$this->db->insert_id();
	$a['loid']=$log;
	$this->db->insert('tableone',$a);
}
}
public function ana()
{
	$this->db->select('*');
	$qry=$this->db->get("tableone");

	return $qry;
}




?>