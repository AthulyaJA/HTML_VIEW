<!DOCTYPE html>
<html>
<head>
<style>
input
{
	padding:10px;
	margin:10px;
	background-color:red;
}
	
body{
	 background-image:url("1.jpg");
	 color:white;
	 
	 
}

</style>
<body>

<h1><b><i>Registration</h1>
<form action="insert.php" method="get"><pre>
 FirstName:	<input type="text" name="fname"><br>
Last Name:	<input type="text" name="lname"><br>
Your Email:	<input type="email" name="email"><br>
New Password:	<input type="password" name="pass"><br>
Date of Birth:	<input type="date" name="dob"><br>
<input  style="color:blue"  type="submit" value="Register now"></pre>
</form>
</body>
</html>