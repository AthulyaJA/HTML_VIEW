<html>
<head>
<style>
h1
{
	color:blue;
}
</style>

</head>
<body>


<h1> logout successfully</h1>
</body>
</html>