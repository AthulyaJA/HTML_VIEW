


<html>
<head>
<title></title>

<style>
	body
		{

			background-image:url("../img/1.jpg");
			text-align:center;
			margin-top:100px;

		}
		input
		{

			padding:5px;
		}
</style>
</head>
<body>
<form method="post" action="<?php echo base_url()?>Athu/loginteach">


 <h1><b><i>Login form</h1><pre>
Email:	<input type="email" name="email"></br></br>
password: <input type="text" name="password"></br></br>
<input type=submit value="login">
</i>
</b>
</form>
</body>
</html>
