<?php
class tech_main extends CI_model
{


	
	}


}
?>